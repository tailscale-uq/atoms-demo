import { spawnSync } from 'node:child_process';
// Wrangler migrations maintains its own local applied-migration ledger.
const result = spawnSync(
  'npx',
  [
    'wrangler',
    'd1',
    'migrations',
    'apply',
    'DB',
    '--local',
    '--config',
    'wrangler.local.json',
  ],
  { stdio: 'inherit' },
);
process.exit(result.status ?? 1);
