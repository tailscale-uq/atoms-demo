import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import ts from 'typescript';
const moduleUrl = (s) =>
  'data:text/javascript;base64,' +
  Buffer.from(
    ts.transpileModule(s, {
      compilerOptions: {
        module: ts.ModuleKind.ESNext,
        target: ts.ScriptTarget.ES2022,
      },
    }).outputText,
  ).toString('base64');
const validationUrl = moduleUrl(await readFile('lib/validation.ts', 'utf8'));
const { validateHtml, previewDocument } = await import(validationUrl);
const { templates } = await import(
  moduleUrl(await readFile('lib/templates.ts', 'utf8'))
);
for (const html of Object.values(templates)) {
  assert.equal(validateHtml(html), html);
  assert(
    previewDocument(html).startsWith(
      '<meta http-equiv="Content-Security-Policy"',
    ),
  );
  assert(previewDocument(html).includes("connect-src 'none'"));
}
assert.throws(() => validateHtml('<div>not a document</div>'));
assert.throws(() =>
  validateHtml(
    '<html><body><script src="https://evil.test/a.js"></script></body></html>',
  ),
);
assert.throws(() =>
  validateHtml('<html><body><iframe></iframe></body></html>'),
);
assert.throws(() => validateHtml('x'.repeat(180001)));
const { runAgent } = await import(
  moduleUrl(
    (await readFile('lib/agent.ts', 'utf8')).replace(
      "'./validation'",
      JSON.stringify(validationUrl),
    ),
  )
);
let calls = [];
const originalFetch = globalThis.fetch;
const config = {
  key: 'test-only',
  base: 'https://model.test/v1',
  model: 'test-model',
};
try {
  globalThis.fetch = async (url, options) => {
    calls.push(JSON.parse(options.body));
    return Response.json({
      choices: [
        {
          message: {
            content:
              calls.length === 1 ? '计划：可交互任务清单' : templates.kanban,
          },
          finish_reason: 'stop',
        },
      ],
    });
  };
  const events = [];
  const out = await runAgent(
    config,
    '创建任务清单',
    '',
    (e) => events.push(e),
    new AbortController().signal,
  );
  assert.equal(out.html, templates.kanban);
  assert.equal(calls.length, 2);
  assert(events.some((e) => e.type === 'plan'));
  assert.equal(calls[0].messages[1].role, 'user');
  calls = [];
  globalThis.fetch = async (url, options) => {
    calls.push(JSON.parse(options.body));
    return Response.json({
      choices: [
        {
          message: {
            content:
              calls.length === 1
                ? '计划'
                : calls.length === 2
                  ? '<p>broken</p>'
                  : templates.focus,
          },
          finish_reason: 'stop',
        },
      ],
    });
  };
  const repairs = [];
  assert.equal(
    (
      await runAgent(
        config,
        '修改时钟',
        templates.kanban,
        (e) => repairs.push(e),
        new AbortController().signal,
      )
    ).html,
    templates.focus,
  );
  assert.equal(calls.length, 3);
  assert(repairs.some((e) => e.stage === 'repair'));
  assert(calls[1].messages[1].content.includes(templates.kanban));
  globalThis.fetch = async () => new Response('{}', { status: 401 });
  await assert.rejects(
    () => runAgent(config, 'test', '', () => {}, new AbortController().signal),
    /认证失败/,
  );
  globalThis.fetch = async () =>
    Response.json({
      choices: [{ message: { content: 'truncated' }, finish_reason: 'length' }],
    });
  await assert.rejects(
    () => runAgent(config, 'test', '', () => {}, new AbortController().signal),
    /截断/,
  );
} finally {
  globalThis.fetch = originalFetch;
}
console.log(
  'PASS: three templates, preview policy, validation, planning/code generation contract, one repair, provider errors, truncation. Model responses were mocked.',
);
