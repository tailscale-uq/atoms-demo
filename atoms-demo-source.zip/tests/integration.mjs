import assert from 'node:assert/strict';
const base = process.env.TEST_BASE_URL || 'http://localhost:3000';
async function session() {
  const r = await fetch(base + '/api/bootstrap');
  assert.equal(r.status, 200);
  return r.headers.get('set-cookie').split(';')[0];
}
const cookie = await session(),
  other = await session();
async function call(path, data, method = 'POST', c = cookie, origin = base) {
  return fetch(base + path, {
    method: data === undefined ? 'GET' : method,
    headers: { Cookie: c, 'Content-Type': 'application/json', Origin: origin },
    body: data === undefined ? undefined : JSON.stringify(data),
  });
}
assert.equal((await fetch(base + '/api/projects')).status, 401);
const p = await (
  await call('/api/projects', { title: 'Integration test workspace' })
).json();
assert(p.id);
assert.equal(
  (await call('/api/projects/' + p.id, undefined, 'GET', other)).status,
  404,
);
assert.equal(
  (
    await call(
      '/api/projects',
      { title: 'bad' },
      'POST',
      cookie,
      'https://other.test',
    )
  ).status,
  403,
);
assert.equal(
  (await call('/api/generate', { project: p.id, prompt: 'test', mode: 'ai' }))
    .status,
  503,
);
assert.equal(
  (
    await call('/api/generate', {
      project: p.id,
      prompt: 'test',
      mode: 'example',
      template: '__proto__',
    })
  ).status,
  400,
);
let ids = [];
for (const template of ['kanban', 'expense', 'focus']) {
  const r = await call('/api/generate', {
    project: p.id,
    prompt: '测试 ' + template,
    mode: 'example',
    template,
  });
  assert.equal(r.status, 200);
  const events = (await r.text()).trim().split('\n').map(JSON.parse);
  const last = events.at(-1);
  assert.equal(last.type, 'done', JSON.stringify(last));
  ids.push(last.version.id);
  assert(last.version.html.includes('</html>'));
}
let detail = await (await call('/api/projects/' + p.id)).json();
assert.equal(detail.versions.length, 3);
assert.equal(detail.current, ids[2]);
assert.equal(
  (
    await call(
      '/api/projects/' + p.id,
      { action: 'restore', version: ids[0] },
      'PATCH',
    )
  ).status,
  200,
);
detail = await (await call('/api/projects/' + p.id)).json();
assert.equal(detail.current, ids[0]);
assert.equal(detail.versions.length, 3);
const edited = detail.versions
  .find((v) => v.id === ids[0])
  .html.replace('轻任务', '已编辑');
assert.equal(
  (
    await call(
      '/api/projects/' + p.id,
      { action: 'edit', html: edited },
      'PATCH',
    )
  ).status,
  200,
);
detail = await (await call('/api/projects/' + p.id)).json();
assert.equal(detail.versions.length, 4);
assert.equal(detail.versions.find((v) => v.id === detail.current).html, edited);
assert.equal(
  (
    await call(
      '/api/projects/' + p.id,
      { action: 'restore', version: ids[0] },
      'PATCH',
      other,
    )
  ).status,
  404,
);
const files = {
  '/App.js':
    "import React from 'react'; export default function App(){return <h1>React</h1>}",
};
const reactEdit = await call(
  '/api/projects/' + p.id,
  { action: 'edit', files },
  'PATCH',
);
assert.equal(reactEdit.status, 200);
const reactVersion = await reactEdit.json();
detail = await (await call('/api/projects/' + p.id)).json();
assert.deepEqual(
  detail.versions.find((v) => v.id === reactVersion.id).files,
  files,
);
assert.equal(
  (
    await call(
      '/api/projects/' + p.id,
      { action: 'edit', files: { '/../App.js': 'x' } },
      'PATCH',
    )
  ).status,
  400,
);
assert.equal(
  (
    await call(
      '/api/projects/' + p.id,
      { action: 'restore', version: ids[0] },
      'PATCH',
    )
  ).status,
  200,
);
detail = await (await call('/api/projects/' + p.id)).json();
assert.equal(detail.versions.find((v) => v.id === detail.current).files, null);
assert.equal(
  (
    await call(
      '/api/projects/' + p.id,
      { action: 'restore', version: reactVersion.id },
      'PATCH',
    )
  ).status,
  200,
);
const list = await (await call('/api/projects')).json();
assert(list.some((v) => v.id === p.id));
console.log(
  'PASS: session initialization, persistent projects, 3 example runs, edit, restore, ownership isolation, CSRF, missing model, invalid template.',
);
