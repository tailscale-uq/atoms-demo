import {
  db,
  owner,
  writeGuard,
  body,
  json,
  failure,
  HttpError,
} from '@/lib/server';
export async function GET(req: Request) {
  try {
    const result = await db()
      .prepare(
        'SELECT id,title,current,created,updated FROM projects WHERE owner=? ORDER BY updated DESC LIMIT 100',
      )
      .bind(owner(req))
      .all();
    return json(result.results);
  } catch (e) {
    return failure(e);
  }
}
export async function POST(req: Request) {
  try {
    writeGuard(req);
    const session = owner(req);
    const input = await body(req);
    if (typeof input.title !== 'string' || !input.title.trim())
      throw new HttpError(400, '请输入项目名称。');
    const p = {
      id: crypto.randomUUID(),
      title: input.title.trim().slice(0, 80),
      created: Date.now(),
    };
    await db()
      .prepare(
        'INSERT INTO projects(id,owner,title,created,updated) VALUES(?,?,?,?,?)',
      )
      .bind(p.id, session, p.title, p.created, p.created)
      .run();
    return json({ ...p, current: null, updated: p.created }, 201);
  } catch (e) {
    return failure(e);
  }
}
