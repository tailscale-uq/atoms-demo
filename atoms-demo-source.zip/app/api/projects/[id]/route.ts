import {
  db,
  owner,
  writeGuard,
  body,
  json,
  failure,
  HttpError,
  getProject,
  saveVersion,
} from '@/lib/server';
import { validateHtml } from '@/lib/validation';
type Context = { params: Promise<{ id: string }> };
export async function GET(req: Request, ctx: Context) {
  try {
    const { id } = await ctx.params;
    const p = await getProject(id, owner(req));
    const v = await db()
      .prepare('SELECT * FROM versions WHERE project=? ORDER BY created DESC')
      .bind(id)
      .all();
    return json({ ...p, owner: undefined, versions: v.results });
  } catch (e) {
    return failure(e);
  }
}
export async function PATCH(req: Request, ctx: Context) {
  try {
    writeGuard(req);
    const { id } = await ctx.params,
      session = owner(req);
    await getProject(id, session);
    const b = await body(req);
    if (b.action === 'restore') {
      if (typeof b.version !== 'string')
        throw new HttpError(400, '请选择版本。');
      const v = await db()
        .prepare('SELECT id FROM versions WHERE id=? AND project=?')
        .bind(b.version, id)
        .first();
      if (!v) throw new HttpError(404, '版本不存在。');
      await db()
        .prepare(
          'UPDATE projects SET current=?,updated=? WHERE id=? AND owner=?',
        )
        .bind(b.version, Date.now(), id, session)
        .run();
      return json({ ok: true });
    }
    if (b.action === 'edit') {
      let html: string;
      try {
        html = validateHtml(b.html);
      } catch (e) {
        throw new HttpError(
          400,
          e instanceof Error ? e.message : 'HTML 无效。',
        );
      }
      return json(
        await saveVersion(id, session, {
          html,
          prompt: '手动编辑代码',
          plan: '保存手动修改的完整 HTML 文件。',
          mode: 'manual',
        }),
      );
    }
    throw new HttpError(400, '不支持的操作。');
  } catch (e) {
    return failure(e);
  }
}
