import { bindings, json, failure } from '@/lib/server';
export async function GET(req: Request) {
  try {
    const b = bindings();
    const res = json({
      aiReady: !!(b.LLM_API_KEY && b.LLM_MODEL && b.LLM_BASE_URL),
      model: b.LLM_MODEL || '未配置',
      storage: 'D1',
      session: 'anonymous',
    });
    if (
      !req.headers
        .get('cookie')
        ?.match(/(?:^|;\s*)atoms_session=[a-f0-9]{64}(?:;|$)/)
    ) {
      const id = Array.from(crypto.getRandomValues(new Uint8Array(32)), (v) =>
        v.toString(16).padStart(2, '0'),
      ).join('');
      res.headers.set(
        'Set-Cookie',
        `atoms_session=${id}; Path=/; HttpOnly; SameSite=Strict; Max-Age=2592000${new URL(req.url).protocol === 'https:' ? '; Secure' : ''}`,
      );
    }
    return res;
  } catch (e) {
    return failure(e);
  }
}
