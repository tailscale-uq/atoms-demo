import {
  bindings,
  db,
  owner,
  writeGuard,
  body,
  json,
  failure,
  HttpError,
  getProject,
  saveVersion,
} from '@/lib/server';
import { runAgent } from '@/lib/agent';
import { reactExample } from '@/lib/react-example';
import { templates, type TemplateName } from '@/lib/templates';
export async function POST(req: Request) {
  try {
    writeGuard(req);
    const session = owner(req),
      input = await body(req);
    if (
      typeof input.project !== 'string' ||
      typeof input.prompt !== 'string' ||
      !input.prompt.trim() ||
      input.prompt.length > 4000
    )
      throw new HttpError(400, '需求不能为空，且不能超过 4000 字。');
    if (!['ai', 'example'].includes(input.mode))
      throw new HttpError(400, '请选择生成方式。');
    const p = await getProject(input.project, session);
    const b = bindings();
    if (
      input.mode === 'ai' &&
      (!b.LLM_API_KEY || !b.LLM_MODEL || !b.LLM_BASE_URL)
    )
      throw new HttpError(
        503,
        '真实 AI 尚未连接。请配置模型服务，或选择示例体验。',
      );
    if (
      input.mode === 'example' &&
      input.template !== 'react-counter' &&
      !Object.hasOwn(templates, input.template)
    )
      throw new HttpError(400, '请选择一个内置示例。');
    const current = p.current
      ? await db()
          .prepare('SELECT html,files FROM versions WHERE id=? AND project=?')
          .bind(p.current, input.project)
          .first<{ html: string; files: string | null }>()
      : null;
    const format = current?.files
      ? 'react'
      : current
        ? 'html'
        : input.format === 'react'
          ? 'react'
          : 'html';
    const abort = new AbortController();
    const timeout = setTimeout(() => abort.abort(), 180000);
    req.signal.addEventListener('abort', () => abort.abort(), { once: true });
    const encoder = new TextEncoder();
    let cancelled = false;
    const stream = new ReadableStream({
      async start(controller) {
        const emit = (event: Record<string, unknown>) => {
          if (!cancelled)
            controller.enqueue(encoder.encode(JSON.stringify(event) + '\n'));
        };
        try {
          let result;
          if (input.mode === 'example') {
            emit({
              type: 'step',
              stage: 'example',
              message: '正在载入内置示例（不调用 AI）',
            });
            result = {
              html:
                input.template === 'react-counter'
                  ? ''
                  : templates[input.template as TemplateName],
              files: input.template === 'react-counter' ? reactExample : null,
              plan: '载入可交互的内置示例。可以查看源码、保存手动修改，或连接 AI 后通过对话继续修改。',
            };
            emit({ type: 'plan', plan: result.plan });
          } else
            result = await runAgent(
              {
                key: b.LLM_API_KEY!,
                base: b.LLM_BASE_URL!,
                model: b.LLM_MODEL!,
              },
              input.prompt,
              current?.files || current?.html || '',
              emit,
              abort.signal,
              format,
            );
          if (abort.signal.aborted) throw new Error('生成已停止或超时。');
          emit({ type: 'step', stage: 'save', message: '正在保存应用版本' });
          const version = await saveVersion(input.project, session, {
            ...result,
            prompt: input.prompt,
            mode: input.mode,
          });
          emit({ type: 'done', version });
        } catch (e) {
          emit({
            type: 'error',
            message: abort.signal.aborted
              ? '生成已停止或超时，原版本已保留。'
              : e instanceof Error
                ? e.message
                : '生成失败，请重试。',
          });
        } finally {
          clearTimeout(timeout);
          if (!cancelled) controller.close();
        }
      },
      cancel() {
        cancelled = true;
        clearTimeout(timeout);
        abort.abort();
      },
    });
    return new Response(stream, {
      headers: {
        'Content-Type': 'application/x-ndjson; charset=utf-8',
        'Cache-Control': 'no-store',
        'X-Content-Type-Options': 'nosniff',
      },
    });
  } catch (e) {
    return failure(e);
  }
}
