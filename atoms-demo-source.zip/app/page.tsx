'use client';
import { useEffect, useRef, useState } from 'react';
import {
  Sparkles,
  ArrowUp,
  Code2,
  Monitor,
  Smartphone,
  Plus,
  FolderOpen,
  History,
  Download,
  Settings2,
  Globe,
  Command,
  Check,
  LoaderCircle,
  Square,
  RotateCcw,
  Save,
  FlaskConical,
  AlertCircle,
} from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { previewDocument } from '@/lib/validation';
type Project = {
  id: string;
  title: string;
  current: string | null;
  updated: number;
};
type Version = {
  id: string;
  prompt: string;
  plan: string;
  html: string;
  mode: string;
  created: number;
};
type Detail = Project & { versions: Version[] };
type Config = { aiReady: boolean; model: string };
const examples = [
  { id: 'kanban', text: '做一个有分类筛选的任务看板', label: '任务看板' },
  { id: 'expense', text: '做一个支持收支统计的记账工具', label: '收支账本' },
  { id: 'focus', text: '做一个可以切换时长的番茄钟', label: '专注时钟' },
];
async function api<T = unknown>(path: string, options?: RequestInit) {
  const r = await fetch(path, options);
  const data = await r.json();
  if (!r.ok) throw new Error((data as { error?: string }).error || '请求失败');
  return data as T;
}
const request = (data: unknown, method = 'POST') => ({
  method,
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(data),
});
const date = (n: number) =>
  new Date(n).toLocaleString('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
export default function Home() {
  const [prompt, setPrompt] = useState(''),
    [config, setConfig] = useState<Config | null>(null),
    [projects, setProjects] = useState<Project[]>([]),
    [project, setProject] = useState<Detail | null>(null),
    [modal, setModal] = useState<'projects' | 'history' | 'settings' | null>(
      null,
    ),
    [error, setError] = useState(''),
    [notice, setNotice] = useState(''),
    [busy, setBusy] = useState(false),
    [stage, setStage] = useState(''),
    [plan, setPlan] = useState(''),
    [activePrompt, setActivePrompt] = useState(''),
    [mobile, setMobile] = useState(false),
    [tab, setTab] = useState('preview'),
    [code, setCode] = useState(''),
    [mode, setMode] = useState<'ai' | 'example'>('example'),
    [example, setExample] = useState('kanban'),
    [ready, setReady] = useState(false);
  const controller = useRef<AbortController | null>(null),
    busyRef = useRef(false),
    actions = useRef<{
      read: () => unknown;
      select: (id: string) => Promise<unknown>;
    }>({ read: () => ({}), select: async () => ({}) });
  const current = project?.versions.find((v) => v.id === project.current);
  const dirty = !!current && code !== current.html;
  async function refresh() {
    const list = await api<Project[]>('/api/projects');
    setProjects(list);
    return list as Project[];
  }
  async function openProject(id: string) {
    const p = await api<Detail>('/api/projects/' + id);
    setProject(p);
    setCode(p.versions.find((v: Version) => v.id === p.current)?.html || '');
    setModal(null);
    setError('');
    setNotice('');
    setActivePrompt('');
    return p;
  }
  useEffect(() => {
    let live = true;
    (async () => {
      try {
        const cfg = await api<Config>('/api/bootstrap');
        if (!live) return;
        setConfig(cfg);
        setMode(cfg.aiReady ? 'ai' : 'example');
        const list = await api<Project[]>('/api/projects');
        if (!live) return;
        setProjects(list);
        setReady(true);
      } catch (e) {
        if (live) setError(e instanceof Error ? e.message : '初始化失败');
      }
    })();
    return () => {
      live = false;
      controller.current?.abort();
    };
  }, []);
  useEffect(() => {
    setCode(current?.html || '');
  }, [current?.id, current?.html]);
  actions.current = {
    read: () => ({
      project: project
        ? { id: project.id, title: project.title, version: project.current }
        : null,
      projects: projects.map((p) => ({ id: p.id, title: p.title })),
      busy: busyRef.current,
      aiReady: config?.aiReady,
    }),
    select: async (id) => {
      if (busyRef.current || dirty)
        throw new Error('请等待当前操作完成并保存修改。');
      if (!projects.some((p) => p.id === id)) throw new Error('项目不存在');
      const p = await openProject(id);
      return { id: p.id, title: p.title, version: p.current };
    },
  };
  useEffect(() => {
    const context = (
      document as Document & {
        modelContext?: {
          registerTool: (
            tool: unknown,
            options: { signal: AbortSignal },
          ) => void | Promise<void>;
        };
      }
    ).modelContext;
    if (!context) return;
    const life = new AbortController();
    for (const tool of [
      {
        name: 'read_workspace',
        description: '读取当前工作台项目与生成状态，不包含代码或密钥。',
        inputSchema: {
          type: 'object',
          properties: {},
          additionalProperties: false,
        },
        annotations: { readOnlyHint: true },
        execute: () => actions.current.read(),
      },
      {
        name: 'open_saved_project',
        description: '在工作台打开已保存的项目，不修改数据库。',
        inputSchema: {
          type: 'object',
          properties: { id: { type: 'string' } },
          required: ['id'],
          additionalProperties: false,
        },
        annotations: { readOnlyHint: false },
        execute: async (input: unknown) => {
          if (
            !input ||
            typeof input !== 'object' ||
            typeof (input as { id?: unknown }).id !== 'string'
          )
            throw new Error('需要项目 id');
          return actions.current.select((input as { id: string }).id);
        },
      },
    ]) {
      try {
        Promise.resolve(
          context.registerTool(tool, { signal: life.signal }),
        ).catch(() => {});
      } catch {}
    }
    return () => life.abort();
  }, []);
  async function generate() {
    if (busyRef.current || !ready) return;
    if (dirty) {
      setError('请先保存代码修改，再继续生成。');
      return;
    }
    const text = prompt.trim();
    if (!text) {
      setError('先描述你想做的应用。');
      return;
    }
    if (
      mode === 'example' &&
      text !== examples.find((e) => e.id === example)?.text
    ) {
      setError(
        '示例模式只载入下方固定示例，不理解自定义需求。请选一个示例，或连接 AI。',
      );
      return;
    }
    busyRef.current = true;
    setBusy(true);
    setError('');
    setNotice('');
    setPlan('');
    setActivePrompt(text);
    setStage('准备项目');
    const abort = new AbortController();
    controller.current = abort;
    try {
      let p = project;
      if (!p) {
        const created = await api<Project>(
          '/api/projects',
          request({ title: text.slice(0, 36) }),
        );
        p = { ...created, versions: [] };
        setProject(p);
        await refresh();
      }
      const res = await fetch('/api/generate', {
        ...request({ project: p.id, prompt: text, mode, template: example }),
        signal: abort.signal,
      });
      if (!res.ok) {
        const data = (await res.json()) as { error?: string };
        throw new Error(data.error || '生成失败');
      }
      if (!res.body) throw new Error('服务未返回内容');
      const reader = res.body.getReader(),
        decoder = new TextDecoder();
      let buffer = '',
        completed = false;
      const handle = (line: string) => {
        if (!line.trim()) return;
        const event = JSON.parse(line);
        if (event.type === 'step') setStage(event.message);
        if (event.type === 'plan') setPlan(event.plan);
        if (event.type === 'error') throw new Error(event.message);
        if (event.type === 'done') {
          completed = true;
          setStage('版本已保存');
          setPrompt('');
          setTab('preview');
        }
      };
      while (true) {
        const { done, value } = await reader.read();
        if (done) {
          buffer += decoder.decode();
          if (buffer.trim()) handle(buffer);
          break;
        }
        buffer += decoder.decode(value, { stream: true });
        let i;
        while ((i = buffer.indexOf('\n')) >= 0) {
          handle(buffer.slice(0, i));
          buffer = buffer.slice(i + 1);
        }
      }
      if (!completed)
        throw new Error('连接提前结束，请重新打开项目检查保存结果。');
      await openProject(p.id);
      await refresh();
      setNotice('已保存新版本，可继续修改或导出。');
    } catch (e) {
      setError(
        e instanceof Error && e.name === 'AbortError'
          ? '已停止等待；如保存已经开始，可重新打开项目检查最新版本。'
          : e instanceof Error
            ? e.message
            : '生成失败',
      );
    } finally {
      busyRef.current = false;
      setBusy(false);
      controller.current = null;
    }
  }
  async function restore(v: Version) {
    if (!project || busyRef.current) return;
    busyRef.current = true;
    setBusy(true);
    setError('');
    try {
      await api(
        '/api/projects/' + project.id,
        request({ action: 'restore', version: v.id }, 'PATCH'),
      );
      await openProject(project.id);
      await refresh();
      setNotice('已切换到历史版本，其他版本仍然保留。');
    } catch (e) {
      setError(e instanceof Error ? e.message : '回退失败');
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }
  async function saveCode() {
    if (!project || busyRef.current) return;
    busyRef.current = true;
    setBusy(true);
    setError('');
    try {
      await api(
        '/api/projects/' + project.id,
        request({ action: 'edit', html: code }, 'PATCH'),
      );
      await openProject(project.id);
      await refresh();
      setNotice('代码修改已保存为新版本。');
    } catch (e) {
      setError(e instanceof Error ? e.message : '保存失败');
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }
  function newProject() {
    if (busy || dirty) return;
    setProject(null);
    setPrompt('');
    setCode('');
    setActivePrompt('');
    setPlan('');
    setError('');
    setNotice('');
    setTab('preview');
  }
  function download() {
    if (!current) return;
    const url = URL.createObjectURL(
      new Blob([current.html], { type: 'text/html;charset=utf-8' }),
    );
    const a = document.createElement('a');
    a.href = url;
    a.download = 'atoms-app.html';
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    setNotice('已导出当前保存版本的 HTML 文件。');
  }
  const messages = project?.versions.slice().reverse() || [];
  return (
    <main className="studio">
      <header className="topbar">
        <a className="brand" href="/">
          <span className="brandmark">
            <Command size={21} />
          </span>{' '}
          atoms<span className="demo">DEMO</span>
        </a>
        <div className="project-name">
          我的工作空间 <span>/</span>
          {project?.title || '新项目'}
        </div>
        <button
          className="quiet"
          disabled={busy || dirty || !ready}
          onClick={() => setModal('projects')}
        >
          <FolderOpen size={16} />
          我的项目 <span className="count">{projects.length}</span>
        </button>
      </header>
      <section className="workspace">
        <aside className="conversation">
          <div className="panel-head">
            <span>
              <Sparkles size={17} /> 创作助手
            </span>
            <button
              className="icon"
              aria-label="新建项目"
              title={dirty ? '请先保存代码' : '新建项目'}
              disabled={busy || dirty}
              onClick={newProject}
            >
              <Plus size={18} />
            </button>
          </div>
          {!project?.versions.length && !busy ? (
            <div className="intro">
              <div className="eyebrow">FROM IDEA TO INTERFACE</div>
              <h1>
                你的想法，
                <br />
                <em>即刻成形。</em>
              </h1>
              <p>描述你想做的应用。一起规划、编写代码，并在右侧看到它运行。</p>
              <div className="suggestions">
                {examples.map((s, i) => (
                  <button
                    key={s.id}
                    onClick={() => {
                      setPrompt(s.text);
                      setExample(s.id);
                      setError('');
                    }}
                  >
                    <span>0{i + 1}</span>
                    {s.text}
                    <ArrowUp size={15} />
                  </button>
                ))}
              </div>
              <div className="hint">
                <span className="status-dot" />
                {config?.aiReady
                  ? 'AI 已连接，可以开始创作'
                  : '先用示例体验完整流程'}
              </div>
            </div>
          ) : (
            <div className="messages">
              {messages.map((v, i) => (
                <article className="exchange" key={v.id}>
                  <div className="user-message">{v.prompt}</div>
                  <div className="agent-message">
                    <div className="agent-label">
                      <Sparkles size={15} />
                      {v.mode === 'example'
                        ? '示例助手'
                        : v.mode === 'manual'
                          ? '代码编辑'
                          : '创作助手'}
                      <span>V{i + 1}</span>
                    </div>
                    <p>{v.plan}</p>
                    <button
                      className="version-card"
                      disabled={busy || dirty}
                      onClick={() => restore(v)}
                    >
                      <div>
                        <Code2 size={18} />
                        <span>
                          index.html
                          <small>
                            {date(v.created)} ·{' '}
                            {v.mode === 'example'
                              ? '内置示例'
                              : v.mode === 'manual'
                                ? '手动修改'
                                : 'AI 生成'}
                          </small>
                        </span>
                      </div>
                      {v.id === project?.current ? (
                        <Check size={17} />
                      ) : (
                        <RotateCcw size={15} />
                      )}
                    </button>
                  </div>
                </article>
              ))}
              {busy && activePrompt && (
                <article className="exchange">
                  <div className="user-message">{activePrompt}</div>
                  <div className="agent-message">
                    <div className="agent-label">
                      <LoaderCircle className="spin" size={15} />
                      创作助手
                    </div>
                    {plan && <p>{plan}</p>}
                    <div className="progress-label" role="status">
                      {stage}
                    </div>
                  </div>
                </article>
              )}
            </div>
          )}
          {(error || notice) && (
            <div
              className={error ? 'feedback error' : 'feedback'}
              role={error ? 'alert' : 'status'}
            >
              {error ? <AlertCircle size={15} /> : <Check size={15} />}
              <span>{error || notice}</span>
            </div>
          )}
          <form
            className="composer"
            onSubmit={(e) => {
              e.preventDefault();
              void generate();
            }}
          >
            <textarea
              aria-label="描述应用需求"
              placeholder={
                current ? '描述下一步要修改的内容…' : '你想构建什么？'
              }
              value={prompt}
              disabled={busy}
              maxLength={4000}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                  e.preventDefault();
                  void generate();
                }
              }}
            />
            <div>
              <button
                className="quiet"
                type="button"
                disabled={busy}
                onClick={() => setModal('settings')}
              >
                {mode === 'example' ? (
                  <FlaskConical size={14} />
                ) : (
                  <Sparkles size={14} />
                )}{' '}
                {mode === 'example' ? '示例体验' : '真实 AI'}
                <Settings2 size={12} />
              </button>
              {busy ? (
                <button
                  className="send"
                  type="button"
                  aria-label="停止生成"
                  onClick={() => controller.current?.abort()}
                >
                  <Square size={15} />
                </button>
              ) : (
                <button
                  className="send"
                  disabled={!ready || !prompt.trim() || dirty}
                  aria-label="开始生成"
                >
                  <ArrowUp size={18} />
                </button>
              )}
            </div>
          </form>
          <p className="footnote">
            {mode === 'example'
              ? '示例模式不调用 AI · 自定义需求需要连接模型'
              : '⌘ / Ctrl + Enter 发送 · AI 结果需要检查'}
          </p>
        </aside>
        <section className="output">
          <Tabs
            value={tab}
            onValueChange={(v) => setTab(String(v))}
            className="output-tabs"
          >
            <div className="preview-toolbar">
              <TabsList>
                <TabsTrigger value="preview">
                  <Monitor size={15} />
                  预览
                </TabsTrigger>
                <TabsTrigger value="code">
                  <Code2 size={15} />
                  代码{dirty ? ' •' : ''}
                </TabsTrigger>
              </TabsList>
              <div className="toolbar-actions">
                <button
                  className={'icon ' + (mobile ? 'selected' : '')}
                  aria-label={mobile ? '切换桌面预览' : '切换移动端预览'}
                  aria-pressed={mobile}
                  onClick={() => setMobile(!mobile)}
                >
                  <Smartphone size={16} />
                </button>
                <button
                  className="quiet"
                  disabled={!current || busy || dirty}
                  onClick={() => setModal('history')}
                >
                  <History size={15} />
                  版本
                </button>
                <button
                  className="quiet"
                  disabled={!current}
                  onClick={download}
                >
                  <Download size={15} />
                  导出
                </button>
              </div>
            </div>
            <TabsContent
              value="preview"
              className={'canvas ' + (current ? 'has-preview' : '')}
            >
              {current ? (
                <div className={'frame-wrap ' + (mobile ? 'mobile' : '')}>
                  <div className="frame-address">
                    <span className="status-dot" /> {project?.title}
                    <span>
                      V
                      {project!.versions.length -
                        project!.versions.findIndex((v) => v.id === current.id)}
                    </span>
                  </div>
                  <iframe
                    title="生成应用的隔离预览"
                    key={current.id}
                    srcDoc={previewDocument(current.html)}
                    sandbox="allow-scripts"
                    referrerPolicy="no-referrer"
                  />
                </div>
              ) : (
                <div className="empty-preview">
                  <div className="preview-symbol">
                    <Code2 size={34} />
                  </div>
                  <h2>下一件作品，从这里开始</h2>
                  <p>
                    {busy
                      ? '正在生成应用，请稍候。'
                      : '发送你的想法，生成的应用将在这里运行。'}
                  </p>
                  <div className="steps">
                    <span>01 理解需求</span>
                    <i />
                    <span>02 生成应用</span>
                    <i />
                    <span>03 预览与迭代</span>
                  </div>
                </div>
              )}
            </TabsContent>
            <TabsContent value="code" className="canvas code-panel">
              {current ? (
                <>
                  <div className="code-header">
                    <span>
                      index.html · {new Blob([code]).size.toLocaleString()}{' '}
                      bytes
                    </span>
                    <button
                      className="quiet"
                      disabled={!dirty || busy}
                      onClick={saveCode}
                    >
                      <Save size={15} />
                      保存为新版本
                    </button>
                  </div>
                  <textarea
                    className="code-editor"
                    aria-label="HTML 源码编辑器"
                    spellCheck={false}
                    value={code}
                    disabled={busy}
                    onChange={(e) => setCode(e.target.value)}
                  />
                </>
              ) : (
                <div className="empty-preview">生成后可在此查看和编辑代码</div>
              )}
            </TabsContent>
          </Tabs>
          <footer className="canvas-footer">
            <span>
              <Globe size={13} />{' '}
              {current ? '隔离预览 · 应用内数据刷新后重置' : '隔离预览环境'}
            </span>
            <span>
              {current ? '项目与代码已保存' : 'HTML · CSS · JavaScript'}
            </span>
          </footer>
        </section>
      </section>
      <Dialog
        open={modal !== null}
        onOpenChange={(open) => {
          if (!open) setModal(null);
        }}
      >
        <DialogContent className="studio-dialog">
          <DialogHeader>
            <DialogTitle>
              {modal === 'projects'
                ? '我的项目'
                : modal === 'history'
                  ? '版本历史'
                  : '生成方式'}
            </DialogTitle>
            <DialogDescription>
              {modal === 'projects'
                ? '项目保存在服务器，通过当前浏览器会话识别。'
                : modal === 'history'
                  ? '选择一个历史版本恢复预览，所有版本均会保留。'
                  : '可先体验示例，也可以连接模型后自由创作。'}
            </DialogDescription>
          </DialogHeader>
          {modal === 'projects' && (
            <div className="dialog-list">
              {projects.length ? (
                projects.map((p) => (
                  <button
                    key={p.id}
                    className="list-item"
                    onClick={() => {
                      void openProject(p.id).catch((e) => setError(e.message));
                    }}
                  >
                    <FolderOpen size={18} />
                    <span>
                      {p.title}
                      <small>{date(p.updated)}</small>
                    </span>
                  </button>
                ))
              ) : (
                <p className="muted-text">还没有项目，发送一个需求开始。</p>
              )}
            </div>
          )}
          {modal === 'history' && (
            <div className="dialog-list">
              {project?.versions.map((v, i) => (
                <button
                  className="list-item"
                  key={v.id}
                  onClick={() => restore(v)}
                >
                  <span className="version-number">
                    V{project.versions.length - i}
                  </span>
                  <span>
                    {v.prompt}
                    <small>
                      {date(v.created)} ·{' '}
                      {v.mode === 'example'
                        ? '内置示例'
                        : v.mode === 'manual'
                          ? '手动编辑'
                          : 'AI 生成'}
                    </small>
                  </span>
                  {v.id === project.current && <Check size={17} />}
                </button>
              ))}
            </div>
          )}
          {modal === 'settings' && (
            <div className="settings">
              <button
                className={
                  'mode-option ' + (mode === 'example' ? 'chosen' : '')
                }
                onClick={() => setMode('example')}
              >
                <FlaskConical size={20} />
                <span>
                  示例体验<small>载入预设应用，不调用 AI，不消耗额度。</small>
                </span>
                {mode === 'example' && <Check size={17} />}
              </button>
              <button
                className={'mode-option ' + (mode === 'ai' ? 'chosen' : '')}
                disabled={!config?.aiReady}
                onClick={() => setMode('ai')}
              >
                <Sparkles size={20} />
                <span>
                  真实 AI
                  <small>
                    {config?.aiReady ? config.model : '尚未配置模型服务'}
                  </small>
                </span>
                {mode === 'ai' && <Check size={17} />}
              </button>
              {!config?.aiReady && (
                <p className="setting-note">
                  模型尚未连接。部署者配置模型服务后，刷新页面即可使用。密钥仅保留在服务端。
                </p>
              )}
              <div className="example-picker">
                <p>选择一个可交互的示例</p>
                {examples.map((e) => (
                  <button
                    key={e.id}
                    onClick={() => {
                      setMode('example');
                      setExample(e.id);
                      setPrompt(e.text);
                      setModal(null);
                    }}
                  >
                    {e.label}
                    <ArrowUp size={14} />
                  </button>
                ))}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </main>
  );
}
