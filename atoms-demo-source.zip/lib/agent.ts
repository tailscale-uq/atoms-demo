import { validateHtml } from './validation';
import { parseFiles } from './files';
type Config = { key: string; base: string; model: string };
export type Emit = (event: Record<string, unknown>) => void;
async function complete(
  config: Config,
  system: string,
  user: string,
  max: number,
  signal: AbortSignal,
) {
  const url = new URL(config.base.replace(/\/$/, '') + '/chat/completions');
  if (url.protocol !== 'https:') throw new Error('模型服务必须使用 HTTPS。');
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${config.key}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: config.model,
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: user },
      ],
      max_tokens: max,
      stream: false,
    }),
    signal,
  });
  if (!res.ok)
    throw new Error(
      res.status === 401
        ? '模型认证失败，请检查服务端密钥。'
        : res.status === 429
          ? '模型额度或频率受限，请稍后重试。'
          : `模型服务返回错误 (${res.status})。`,
    );
  const data = (await res.json()) as {
    choices?: { message?: { content?: string }; finish_reason?: string }[];
  };
  const result = data.choices?.[0];
  if (result?.finish_reason === 'length')
    throw new Error('模型输出被截断，请缩小应用范围后重试。');
  if (!result?.message?.content) throw new Error('模型没有返回可用内容。');
  return result.message.content;
}
export async function runAgent(
  config: Config,
  prompt: string,
  previous: string,
  emit: Emit,
  signal: AbortSignal,
  format: 'html' | 'react' = 'html',
) {
  emit({ type: 'step', stage: 'plan', message: '正在分析需求与拆分交互' });
  const plan = await complete(
    config,
    `生成格式：${format}。你是网页应用产品规划师。用中文输出简洁可执行计划：目标、三个以内核心交互、验收点。只规划可在浏览器中运行的前端应用。不可要求外部API、库、图片或注册。若有已有应用，说明保留的功能与本次修改。最多300字。`,
    `用户需求：${prompt}\n已有应用：${previous ? previous.slice(0, 24000) : '无'}`,
    1200,
    signal,
  );
  emit({ type: 'plan', plan });
  emit({ type: 'step', stage: 'code', message: '正在编写页面、样式与交互' });
  const system =
    format === 'react'
      ? '你是 React 工程师。只输出 JSON：{"files":{"/App.js":"代码","/styles.css":"样式","/components/Counter.js":"代码"}}。使用 React 18 JSX，App 默认导出，所有 JSX 文件显式 import React。按功能拆分组件，App 引入 CSS。仅依赖 react/react-dom 和本地文件，不要输出 package.json/index.js，不使用外部API/URL/图片/存储/弹窗。中文响应式界面，控件全部可操作，数据用内存。保留现有功能，只修改用户要求部分。最多20文件，总代码150KB。'
      : '你是前端工程师。只输出完整自包含HTML，以<!DOCTYPE html>开头，以</html>结尾，不要Markdown。含head/body、内联CSS/JS，响应式布局，中文界面。所有控件必须实际工作。禁止外部脚本、图片URL、fetch、iframe、object、embed、跳转、外部字体。运行环境为sandbox iframe，无同源权限，不可使用localStorage/cookie。数据使用内存；不要宣称刷新后持久化。禁止alert/prompt/confirm，使用页面内反馈。渲染用户文本用textContent避免XSS。保留现有交互，仅执行用户请求修改。';
  let html = await complete(
    config,
    system,
    `计划：${plan}\n用户需求：${prompt}\n已有完整代码：${previous || '无'}`,
    10000,
    signal,
  );
  emit({ type: 'step', stage: 'check', message: '检查网页结构与预览兼容性' });
  const validate = (raw: string) =>
    format === 'react'
      ? JSON.stringify({ files: parseFiles(raw) })
      : validateHtml(raw);
  try {
    html = validate(html);
  } catch (e) {
    emit({
      type: 'step',
      stage: 'repair',
      message: '检测到结构问题，正在修复一次',
    });
    html = validate(
      await complete(
        config,
        system,
        `修复以下代码。问题：${e instanceof Error ? e.message : '结构无效'}\n代码：${html}`,
        10000,
        signal,
      ),
    );
  }
  return format === 'react'
    ? { html: '', files: parseFiles(html), plan }
    : { html, files: null, plan };
}
