export const reactExample = {
  '/App.js': `import React from 'react';
import Counter from './components/Counter';
import './styles.css';
export default function App(){return <main><small>REACT PLAYGROUND</small><h1>每一步，都算数。</h1><p>一个可交互的多文件 React 示例</p><Counter/></main>}`,
  '/components/Counter.js': `import React, {useState} from 'react';
export default function Counter(){const [count,setCount]=useState(0);return <section><output aria-label="当前计数">{count}</output><div><button onClick={()=>setCount(c=>c-1)}>减一</button><button onClick={()=>setCount(c=>c+1)}>加一</button><button onClick={()=>setCount(0)}>重置</button></div></section>}`,
  '/styles.css': `*{box-sizing:border-box}body{margin:0;background:#f0f6f2;color:#193b2b;font-family:system-ui}main{max-width:650px;margin:10vh auto;padding:32px}small{letter-spacing:3px;color:#5f806c}h1{font-size:clamp(28px,5vw,44px)}p{color:#6a8174}section{background:white;padding:35px;border-radius:20px;margin-top:32px;box-shadow:0 15px 50px #234c2810}output{display:block;font-size:76px;font-weight:700;margin-bottom:24px}section div{display:flex;gap:12px;flex-wrap:wrap}button{border:0;background:#244b37;color:white;border-radius:10px;padding:12px 24px;cursor:pointer}button:last-child{background:#e7f0e9;color:#244b37}`,
};
