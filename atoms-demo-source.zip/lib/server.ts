import { env } from 'cloudflare:workers';
export type Bindings = {
  DB: D1Database;
  LLM_API_KEY?: string;
  LLM_BASE_URL?: string;
  LLM_MODEL?: string;
};
export const bindings = () => env as unknown as Bindings;
export const db = () => bindings().DB;
export function owner(req: Request) {
  const id = req.headers
    .get('cookie')
    ?.match(/(?:^|;\s*)atoms_session=([a-f0-9]{64})(?:;|$)/)?.[1];
  if (!id) throw new HttpError(401, '会话已失效，请刷新页面。');
  return id;
}
export class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}
export function writeGuard(req: Request) {
  const origin = req.headers.get('origin');
  if (origin && origin !== new URL(req.url).origin)
    throw new HttpError(403, '请求来源无效。');
  if (!req.headers.get('content-type')?.startsWith('application/json'))
    throw new HttpError(415, '请使用 JSON 请求。');
}
export async function body(req: Request) {
  const raw = await req.text();
  if (raw.length > 250000) throw new HttpError(413, '内容过大。');
  try {
    return JSON.parse(raw);
  } catch {
    throw new HttpError(400, '请求格式无效。');
  }
}
export const json = (value: unknown, status = 200) =>
  Response.json(value, { status, headers: { 'Cache-Control': 'no-store' } });
export function failure(e: unknown) {
  if (e instanceof HttpError) return json({ error: e.message }, e.status);
  console.error('Request failed', e instanceof Error ? e.name : 'unknown');
  return json({ error: '暂时无法完成请求，请稍后重试。' }, 500);
}
export async function getProject(id: string, session: string) {
  const p = await db()
    .prepare('SELECT * FROM projects WHERE id=? AND owner=?')
    .bind(id, session)
    .first();
  if (!p) throw new HttpError(404, '项目不存在或无法访问。');
  return p;
}
export async function saveVersion(
  id: string,
  session: string,
  data: {
    prompt: string;
    plan: string;
    html: string;
    files?: Record<string, string> | null;
    mode: string;
  },
) {
  await getProject(id, session);
  const vid = crypto.randomUUID(),
    now = Date.now();
  await db().batch([
    db()
      .prepare(
        'INSERT INTO versions (id,project,prompt,plan,html,mode,created,files) VALUES (?,?,?,?,?,?,?,?)',
      )
      .bind(
        vid,
        id,
        data.prompt,
        data.plan,
        data.html,
        data.mode,
        now,
        data.files ? JSON.stringify(data.files) : null,
      ),
    db()
      .prepare('UPDATE projects SET current=?,updated=? WHERE id=? AND owner=?')
      .bind(vid, now, id, session),
  ]);
  return { id: vid, project: id, ...data, created: now };
}
