export type AppFiles = Record<string, string>;
export function validateFiles(value: unknown): AppFiles {
  if (!value || typeof value !== 'object' || Array.isArray(value))
    throw new Error('React 项目必须包含文件对象。');
  const entries = Object.entries(value);
  if (!entries.length || entries.length > 20)
    throw new Error('项目需要 1–20 个文件。');
  const files: AppFiles = {};
  let size = 0;
  for (const [path, code] of entries) {
    if (
      !/^\/(?:[a-zA-Z0-9_-]+\/)*[a-zA-Z0-9_-]+\.(?:jsx?|css)$/.test(path) ||
      path === '/index.js'
    )
      throw new Error(
        '仅支持绝对路径的 JS、JSX、CSS 文件；index.js 由工作台管理。',
      );
    if (typeof code !== 'string') throw new Error('文件内容必须是文本。');
    size += code.length;
    if (size > 150000) throw new Error('React 项目代码超过 150 KB 限制。');
    files[path] = code;
  }
  if (!files['/App.js'] && !files['/App.jsx'])
    throw new Error('需要 /App.js 或 /App.jsx 作为应用入口。');
  if (files['/App.js'] && files['/App.jsx'])
    throw new Error('只能保留一个 App 入口。');
  return files;
}
export function parseFiles(raw: string): AppFiles {
  const data = JSON.parse(
    raw
      .trim()
      .replace(/^```(?:json)?\s*/i, '')
      .replace(/\s*```$/, ''),
  );
  return validateFiles(data.files || data);
}
export function reactEntry(files: AppFiles) {
  return `import React from 'react';\nimport { createRoot } from 'react-dom/client';\nimport App from '${files['/App.jsx'] ? './App.jsx' : './App.js'}';\ncreateRoot(document.getElementById('root')).render(<App />);`;
}
