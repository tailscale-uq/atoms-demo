export function validateHtml(value: unknown): string {
  if (typeof value !== 'string') throw new Error('生成结果不是 HTML 文本。');
  const html = value
    .trim()
    .replace(/^```(?:html)?\s*/i, '')
    .replace(/\s*```$/, '');
  if (html.length > 180000) throw new Error('应用代码超出 180 KB 限制。');
  if (
    !/<html[\s>]/i.test(html) ||
    !/<\/html>/i.test(html) ||
    !/<body[\s>]/i.test(html)
  )
    throw new Error('生成结果必须是包含 html 与 body 的完整网页。');
  if (
    /<script[^>]+src\s*=|<iframe\b|<object\b|<embed\b|<base\b|http-equiv\s*=\s*["']?refresh/i.test(
      html,
    )
  )
    throw new Error(
      '预览仅支持自包含 HTML，不支持外部脚本、嵌入页或自动跳转。',
    );
  return html;
}
export function previewDocument(html: string) {
  const csp = `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; font-src data:; connect-src 'none'; form-action 'none'; base-uri 'none';">`;
  return csp + html;
}
