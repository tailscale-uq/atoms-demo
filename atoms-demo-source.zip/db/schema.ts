import { sqliteTable, text, integer, index } from 'drizzle-orm/sqlite-core';
export const projects = sqliteTable(
  'projects',
  {
    id: text('id').primaryKey(),
    owner: text('owner').notNull(),
    title: text('title').notNull(),
    current: text('current'),
    created: integer('created').notNull(),
    updated: integer('updated').notNull(),
  },
  (t) => [index('projects_owner_updated').on(t.owner, t.updated)],
);
export const versions = sqliteTable(
  'versions',
  {
    id: text('id').primaryKey(),
    project: text('project')
      .notNull()
      .references(() => projects.id),
    prompt: text('prompt').notNull(),
    plan: text('plan').notNull(),
    html: text('html').notNull(),
    files: text('files'),
    mode: text('mode').notNull(),
    created: integer('created').notNull(),
  },
  (t) => [index('versions_project_created').on(t.project, t.created)],
);
