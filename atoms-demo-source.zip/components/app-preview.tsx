'use client';
import { useEffect, useRef, useMemo } from 'react';
import {
  SandpackProvider,
  SandpackPreview,
  useSandpack,
} from '@codesandbox/sandpack-react';
import { previewDocument } from '@/lib/validation';
import { reactEntry, type AppFiles } from '@/lib/files';
function ErrorReporter({ onError }: { onError: (message: string) => void }) {
  const { sandpack, listen } = useSandpack();
  useEffect(() => {
    if (sandpack.error) onError(sandpack.error.message);
  }, [sandpack.error, onError]);
  useEffect(
    () =>
      listen((message) => {
        if (message.type === 'action' && message.action === 'show-error') {
          const m = message as unknown as { message?: string; title?: string };
          onError(m.message || m.title || 'React 预览运行失败');
        }
      }),
    [listen, onError],
  );
  return null;
}
export function AppPreview({
  html,
  files,
  onError,
}: {
  html: string;
  files?: AppFiles | null;
  onError: (message: string) => void;
}) {
  const frame = useRef<HTMLIFrameElement>(null);
  const channel = useMemo(() => crypto.randomUUID(), []);
  useEffect(() => {
    const receive = (event: MessageEvent) => {
      if (
        event.source !== frame.current?.contentWindow ||
        event.data?.channel !== channel ||
        event.data?.type !== 'preview-error'
      )
        return;
      if (typeof event.data.message === 'string')
        onError(event.data.message.slice(0, 2000));
    };
    window.addEventListener('message', receive);
    return () => window.removeEventListener('message', receive);
  }, [channel, onError]);
  if (files)
    return (
      <SandpackProvider
        template="react"
        files={{ ...files, '/index.js': reactEntry(files) }}
        customSetup={{
          dependencies: { react: '18.3.1', 'react-dom': '18.3.1' },
        }}
        options={{ autorun: true, recompileMode: 'immediate' }}
        theme="dark"
      >
        <ErrorReporter onError={onError} />
        <SandpackPreview
          showOpenInCodeSandbox={false}
          showOpenNewtab={false}
          style={{ height: '100%' }}
        />
      </SandpackProvider>
    );
  return (
    <iframe
      ref={frame}
      title="生成应用的隔离预览"
      srcDoc={previewDocument(html, channel)}
      sandbox="allow-scripts"
      referrerPolicy="no-referrer"
    />
  );
}
